I apologize for the misunderstanding! Here’s the complete `README.md` formatted as you requested, starting and ending with triple backticks for easy copying:

```
# 🚀 Fastest & Best Auto MM Bot

Welcome to the **Fastest & Best Auto MM** Discord bot! This bot is designed to enhance your Discord server experience by automating various tasks seamlessly.

---

## 📋 Table of Contents

- [⚙️ Setup](#-setup)
- [🔧 Configuration](#-configuration)
- [🛠️ Features](#-features)
- [📜 License](#-license)
- [💬 Support](#-support)

---

## ⚙️ Setup

### 1. Goto The Folder Directory
```bash
# If you have the repository, navigate to the folder
```

### 2. Install Dependencies
Make sure you have Python installed. Then, install the required packages:
```bash
pip install -r requirements.txt
```

### 3. Create a `config.ini` File
Create a file named `config.ini` in the project directory and include the following configuration:

```ini
[EmbedSettings]
embed_color = 0xFFFFFF
footer_text = Fastest & Best Auto MM
icon_url = https://cdn.discordapp.com/attachments/1288760830065770508/1288760856133505064/letter-m-fire-logo-b551431a-d02b-483b-8c9a-eebd91c86f7b.jpg?ex=66f65b94&is=66f50a14&hm=069133c493e6fd3ec82afceb2900a1f1616d29ef9aee8a1a1fbd79c4794f044d&
thumbnail_url = https://cdn.discordapp.com/attachments/1288760830065770508/1288760856133505064/letter-m-fire-logo-b551431a-d02b-483b-8c9a-eebd91c86f7b.jpg?ex=66f65b94&is=66f50a14&hm=069133c493e6fd3ec82afceb2900a1f1616d29ef9aee8a1a1fbd79c4794f044d&
loading_url = https://www.icegif.com/wp-content/uploads/2023/07/icegif-1263.gif
ltc_image = https://w7.pngwing.com/pngs/786/58/png-transparent-coin-crypto-lite-litecion-ltc-crypto-currency-and-coin-icon.png
tick_image = https://e7.pngegg.com/pngimages/270/706/png-clipart-check-mark-computer-icons-green-tick-mark-angle-text-thumbnail.png

[Token]
TOKEN = YOUR_DISCORD_BOT_TOKEN_HERE

[APIKeys]
TATUM_APIKEY = YOUR_TATUM_API_KEY_HERE

[ChannelSettings]
mm_log_channel_id = YOUR_LOG_CHANNEL_ID
category_id = YOUR_CATEGORY_ID

[RoleSettings]
admin_role_id = YOUR_ADMIN_ROLE_ID
client_role_id = YOUR_CLIENT_ROLE_ID

[DisplaySettings]
show_buyer_seller = True
```

### 4. Run the Bot
Execute the following command to start your bot:
```bash
python main.py
```

---

## 🔧 Configuration

### Embed Settings
- **`embed_color`**: Set the embed color using hex format (e.g., `0xFFFFFF` for white).
- **`footer_text`**: Customize the footer text for the embeds.
- **`icon_url`**: URL for the bot's icon.
- **`thumbnail_url`**: URL for the thumbnail image in embeds.
- **`loading_url`**: URL for a loading GIF.
- **`ltc_image`**: URL for the Litecoin image.
- **`tick_image`**: URL for the tick image.

### Token and API Keys
- **`TOKEN`**: Your Discord bot token.
- **`TATUM_APIKEY`**: Your Tatum API key for cryptocurrency operations.

### Channel and Role Settings
- **`mm_log_channel_id`**: Channel ID for logging messages.
- **`category_id`**: Category ID for organizing channels.
- **`admin_role_id`**: Role ID for admin privileges.
- **`client_role_id`**: Role ID for client privileges.

### Display Settings
- **`show_buyer_seller`**: Set to `True` to display buyer/seller information.

---

## 🛠️ Features
- **Advanced Embed Support**: Customizable embeds for a better user experience.
- **User Management**: Commands to manage users and track transactions.
- **Statistics**: View detailed stats about bot performance and usage.
- **Channel Management**: Easily delete channels with admin permissions.

---

## 📜 License
This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

---

## 💬 Support
For any issues or feature requests, please open an issue in the repository or contact the developer directly.
```